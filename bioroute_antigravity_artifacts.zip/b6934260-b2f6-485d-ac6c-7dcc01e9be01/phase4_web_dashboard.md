# Phase 4 — Web Dashboard (webapp/)

> **Status:** ✅ Complete
> **Files created:** `webapp/index.html`, `webapp/app.js`, `webapp/map.js`, `webapp/styles.css`

---

## What Was Built

The web dashboard is a **single-page application** built with vanilla HTML, JavaScript, and CSS — no build step required. It demonstrates the full pipeline visually with live SSE streaming.

### Layout — 3-Panel Dashboard

```
┌─────────────────────────────────────────────────────────┐
│                  BioRoute Cold-Chain                    │
│               Autonomous AI Command Center              │
├─────────────────┬───────────────────┬───────────────────┤
│  INPUT PANEL    │   AGENT TRACE     │  OUTCOME / MAP    │
│                 │                   │                   │
│ Active ships    │ Live SSE events   │ Before state      │
│ overview        │ streaming in      │ After state       │
│                 │ real time as      │ Route map         │
│ News alert      │ each subagent     │ Notification      │
│ textarea        │ completes         │ log               │
│                 │                   │                   │
│ [Analyze] btn   │ Step timeline     │ [Reset Demo]      │
└─────────────────┴───────────────────┴───────────────────┘
```

### `app.js` — SSE Client

Connects to `POST /api/analyze` using `EventSource` (via `fetch` + `ReadableStream` for POST support). Renders events in real time:

```javascript
// SSE event types handled:
// "agent_step"     → renders a new step card in trace panel
// "tool_call"      → renders CRM update / notification event
// "final_result"   → populates before/after outcome cards
// "error"          → shows error banner
```

Each step card shows:
- Step number + subagent name
- `display_summary` (1-sentence human output)
- `why_brief` badge (≤15 words rationale)
- Raw JSON toggle (expandable)

### `map.js` — Route Visualization

Draws the shipment's before/after route on a simplified SVG map of the Karachi–Hyderabad–Jamshoro corridor:

- **Before**: Primary route (N-5) in green
- **After**: Alternative route (M-9 Thatta Bypass) in orange/red
- Animated dashed line showing reroute transition
- Stop markers with labels (hospital icons at destination)

### `styles.css` — Dark Mode Design

```css
:root {
  --bg-primary: #0a0e1a;
  --bg-card: #111827;
  --accent-blue: #3b82f6;
  --accent-orange: #f97316;
  --accent-red: #ef4444;
  --accent-green: #22c55e;
  --text-primary: #f1f5f9;
  --text-muted: #64748b;
}
```

Key design elements:
- Glassmorphism cards with `backdrop-filter: blur()`
- Pulsing spinner during agent run
- Color-coded severity badges (CRITICAL=red, HIGH=orange, MEDIUM=yellow)
- Smooth step card slide-in animations via `@keyframes`

---

## Usage

```bash
# Option 1: Open directly (no server needed)
xdg-open webapp/index.html

# Option 2: Serve with Python
python3 -m http.server 3000 --directory webapp
# → http://localhost:3000
```

> [!NOTE]
> Backend must be running at `http://localhost:8000` before the dashboard can process alerts. The dashboard shows an error banner if the backend is unreachable.

---

## Scenarios Dropdown

The dashboard fetches `/api/scenarios` on load and populates a dropdown with pre-built news alerts. Selecting a scenario auto-fills the textarea so the demo can run without manual typing.

---

## Reset Flow

The **Reset Demo** button calls `POST /api/reset` which:
1. Restores `active_shipments.json` from baseline
2. Clears `notifications.json`
3. Resets `summary.md`
4. Refreshes the before-state panel to show original "In Transit (On Time)" status
