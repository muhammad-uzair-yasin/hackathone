# Debugging Log — Issues Encountered & Resolved

> A living log of bugs, design pivots, and tricky issues encountered during the 24-hour sprint.

---

## Issue 1 — SSE Streaming with POST in React Native

**Problem:** The mobile app needed to start an SSE stream but `EventSource` (native browser API) only supports `GET` requests. The agent trigger is a `POST /api/analyze`.

**Solution:** Added a parallel `GET /api/stream?input=...` endpoint to the FastAPI server that accepts the news text as a URL query parameter instead of a request body. React Native can use `fetch()` + `ReadableStream` on a GET endpoint.

```python
# Added to server.py
@app.get("/api/stream")
async def stream_get(input: str = Query(...)):
    return StreamingResponse(
        run_agent_stream(input),
        media_type="text/event-stream"
    )
```

```typescript
// React Native SSE workaround
const response = await fetch(`${API_URL}/api/stream?input=${encodeURIComponent(text)}`);
const reader = response.body!.getReader();
// Read chunks and parse SSE manually
```

---

## Issue 2 — Agent Re-initialization on `--reload`

**Problem:** FastAPI's `--reload` flag watches for file changes and restarts the server. Each restart was re-creating the LangChain agent from scratch, causing a multi-second delay on every save during development.

**Solution:** Singleton pattern in `agent.py`:

```python
_agent = None

def get_agent():
    global _agent
    if _agent is None:
        _agent = build_agent()
    return _agent
```

The agent is created once and cached for the lifetime of the process.

---

## Issue 3 — FilesystemBackend Path Resolution

**Problem:** Subagents called `read_file("/data/active_shipments.json")` but the FilesystemBackend needed to know where `/data/` maps to on disk. Using relative paths caused `FileNotFoundError` when uvicorn was started from a different working directory.

**Solution:** Used `Path(__file__).parent / "data"` (absolute path relative to `agent.py`) as the `root_dir`, ensuring it works regardless of `cwd`.

```python
DATA_DIR = Path(__file__).parent / "data"

backend = CompositeBackend(
    default=StateBackend(),
    routes={
        "/data/": FilesystemBackend(root_dir=str(DATA_DIR), virtual_mode=True),
    },
)
```

---

## Issue 4 — Pydantic Schema Strictness Causing Agent Failures

**Problem:** The `ImpactAnalysis` schema had `alternative_routes: list[AlternativeRoute]` as required. When the impact analyzer ran on a "no hazard" scenario, it had no routes to fill, causing Pydantic validation to fail and crash the agent step.

**Solution:** Made the field optional with a default:

```python
class ImpactAnalysis(BaseModel):
    impact_detected: bool
    alternative_routes: list[AlternativeRoute] = []
    affected_shipment_id: str | None = None
    ...
```

Also added `requires_immediate_action: bool = False` default so the orchestrator's conditional check `if requires_immediate_action OR risk_level HIGH/CRITICAL` always has a valid value.

---

## Issue 5 — Action Planner Picking Blocked Route

**Problem:** In early testing, the `action-planner` occasionally selected alternative A3 (Coastal Route via Thatta) which still partially overlaps with the blocked N-5 corridor near Hyderabad West Bypass.

**Solution:** Added explicit instruction to the `ACTION_PLANNER_PROMPT`:

```
## Rules
- Reject alternatives that still use the blocked corridor.
- Prefer cold-vault handoff for temperature-critical cargo in heat.
```

Also added `notes` field to each alternative route in `active_shipments.json` explicitly flagging which routes avoid vs. share blocked roads, so the LLM has concrete data to base the decision on.

---

## Issue 6 — Demo Reset Not Clearing Summary

**Problem:** After clicking Reset Demo, the web app still showed the old "Emergency Reroute" outcome in the before-state panel because `summary.md` still contained the previous run's pipeline JSON.

**Solution:** The `reset_active_shipments_to_baseline()` helper now also calls `clear_summary_file()`:

```python
def reset_active_shipments_to_baseline() -> bool:
    ...
    clear_summary_file()  # Added this
    return True
```

And `clear_summary_file()` writes the placeholder:

```python
def clear_summary_file() -> None:
    SUMMARY_FILE.write_text(
        "# BioRoute Run Summary\n\n_Waiting for agent run…_\n",
        encoding="utf-8",
    )
```

---

## Issue 7 — Orchestrator Copying Subagent Output Verbatim

**Problem:** The orchestrator was echoing the full `display_summary` from subagents in its coordinator messages, making the agent trace noisy and redundant.

**Solution:** Added explicit constraints to `ORCHESTRATOR_SYSTEM_PROMPT`:

```
## Coordinator voice (you only)
- Speak in short plain sentences (≤20 words). No markdown, no bold.
- Maximum 5 coordinator messages for the whole run.
- Do NOT copy display_summary or why_brief from subagents verbatim.
- Say "received the alert" at most once.
```

---

## Issue 8 — Rate Limit (429) During Multi-Step Run

**Problem:** Running all 4 subagents sequentially in rapid succession hit Anthropic's rate limits on the API tier used for the hackathon.

**Solution:** `ModelRetryMiddleware` with exponential backoff already handles this, but the initial delay was too short (0.5s). Increased to 2s initial delay with 2× backoff:

```python
ModelRetryMiddleware(
    max_retries=3,
    initial_delay=2.0,   # was 0.5
    backoff_factor=2.0,
    max_delay=30.0,
)
```

Total worst-case wait: 2s + 4s + 8s = 14s across 3 retries before failure log.

---

## Issue 9 — expo-notifications Crash in Expo Go SDK 53+

**Problem:** In Expo SDK 53+, remote push notification functionalities are removed from Expo Go. Static imports and module initialization of `expo-notifications` crash the Android client immediately on app startup, rendering the app unusable.

**Solution:** Changed the static import to a dynamic `require('expo-notifications')` wrapped in a `try-catch` inside `NotificationService.ts`. If the initialization fails (such as in Expo Go), the system logs a console warning and falls back to a graceful console-mock mode rather than crashing the React Native environment.

```typescript
let Notifications: any = null;
try {
  Notifications = require('expo-notifications');
  if (Notifications && typeof Notifications.setNotificationHandler === 'function') {
    Notifications.setNotificationHandler({ ... });
  }
} catch (e) {
  console.warn('[Notifications] Failed to load:', e);
}
```

---

## Issue 10 — expo-av "Cannot find native module 'ExponentAV'" Crash

**Problem:** In Expo Go, native modules like `ExponentAV` used by `expo-av` might not be loaded or present depending on the platform environment build. Static imports of `expo-av` threw `Error: Cannot find native module 'ExponentAV'` during startup, crashing the entire application context.

**Solution:** Converted the static import of `expo-av` in [VoiceInputButton.tsx](file:///home/carlow/Documents/hackathone/mobile/src/components/VoiceInputButton.tsx) into a dynamic `require` wrapped in a `try-catch`. When the native module is unavailable, the voice button is styled with a disabled look, and the UI label changes to inform the user that voice recording is unsupported in this environment. This lets the user type their alert or select a scenario instead.
