# BioRoute v2 — Feature Build Tasks
> **Primary UI: React Native Mobile App** (webapp is secondary)

## Phase 1 — Agent Renames ✅ DONE
- [x] `agent.py` — `hazard-extractor` → `hazard-detector`, `fleet-scout` → `shipment-analyzer`
- [x] `server.py` — `_SUBAGENT_STEP` dict updated
- [x] `webapp/app.js` — `AGENT_TO_STEP` dict updated (minor, not priority)

## Phase 2 — Schema Updates ✅ DONE
- [x] `schemas.py` — `confidence_score: float` added to `ActionPlan`
- [x] `schemas.py` — `NotificationSimulation` expanded → 3 recipients (driver / hospital / coordinator)
- [x] `agent.py` — `ACTION_PLANNER_PROMPT` updated for 3-way notifications + confidence score

## Phase 3 — Backend New Endpoints ✅ DONE
- [x] `pyproject.toml` — `reportlab` installed
- [x] `tools.py` — `notify_tool` updated (3 recipients: hospital, driver, coordinator)
- [x] `tools.py` — `append_history()` helper added
- [x] `tools.py` — `HISTORY_FILE` constant added
- [x] `server.py` — `GET /api/summary/pdf` — PDF generation endpoint
- [x] `server.py` — `POST /api/driver-report` — driver issue reporting
- [x] `server.py` — `GET /api/history` — incident history log
- [x] `server.py` — `GET /api/notifications` — full notification log

## Phase 4 — Mobile App (PRIMARY FOCUS) ✅ DONE
### OutcomeVisualization.tsx
- [x] Confidence score badge + progress bar — AI % confidence on action card
- [x] 3-way notification chat bubbles — driver (purple), hospital (green), coordinator (amber)
- [x] PDF download button — calls `GET /api/summary/pdf` + opens via Linking

### IngestionDashboard.tsx
- [x] Temperature gauge per shipment card — color bar: green → yellow → red
- [x] Escalation timer — 5-min countdown, ACK button, auto-turns-green
- [x] Driver Report button linking to new screen

### New Screen — DriverReportScreen.tsx ✅ CREATED
- [x] Shipment ID chip selector (SHP-882..928)
- [x] Issue type grid (breakdown / delay / temperature / accident / fuel / other)
- [x] Location + description fields
- [x] Submit → `POST /api/driver-report` → confirmation + AI synthetic alert preview
- [x] "Re-run AI Agent" button on success screen

### FleetScreen.tsx
- [x] Incident history log accordion — pulls from `GET /api/history`
- [x] Rows: timestamp, shipment, before→after route, REROUTED/UPDATED badge

### Navigation
- [x] `BottomTabBar` — added `Report` tab (⚠️ icon, red accent)
- [x] `App.tsx` — wired Report case, passes onRunAgent to DriverReportScreen

### PredictionScreen.tsx (Predictive Logistics Agent)
- [x] Create `/api/risk-context` GET/POST endpoints on FastAPI server
- [x] Implement sub-tab selector (Dashboard vs Edit Risk Data)
- [x] Wire up state, fetch hooks, and save callbacks
- [x] Create `RiskContextEditor` component for live-editing JSON variables (temp, humidity, traffic, telemetry)
- [x] Apply editor styles with custom selection chips

## Phase 5 — Polish
- [x] TypeScript check — verify compilation after new additions
- [x] End-to-end demo test: extract link → extract PDF → run agent

## Phase 6 — URL & PDF Extractor
- [x] Install expo-document-picker in mobile app
- [x] Add `POST /api/extract/url` endpoint in FastAPI server
- [x] Add `POST /api/extract/pdf` endpoint in FastAPI server
- [x] Update `NewsInputScreen.tsx` with Link and PDF extraction buttons and handlers

## Phase 7 — UI Simplification & Detail Map
- [x] Simplify NewsInputScreen using a Tab Switcher (Scenarios, Text/Voice, URL/PDF)
- [x] Add currently loaded news input preview banner
- [x] Integrate Leaflet WebView Map into ShipmentDetailScreen
- [x] Make ShipmentDetailScreen Map update dynamically on alternate route card tap
- [x] Run typescript checks and verify the build
