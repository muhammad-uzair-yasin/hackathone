# Tasks — Phase 4: Test Scripts

- [x] Create `test_stream.py` — basic POST /api/analyze SSE test
- [x] Create `test_stream2.py` — extended multi-scenario test
- [x] Create `test_stream3.py` — edge case test (no hazard path)
