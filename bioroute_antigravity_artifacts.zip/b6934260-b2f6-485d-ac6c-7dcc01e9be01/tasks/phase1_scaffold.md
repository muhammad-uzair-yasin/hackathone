# Tasks — Phase 1: Project Scaffold & FastAPI Backend

- [x] Create `pyproject.toml` with all Python dependencies
- [x] Set `.python-version` to 3.13
- [x] Create `.gitignore` (Python + Node + .env)
- [x] Create `langchain_agent/__init__.py`
- [x] Create `langchain_agent/api/__init__.py`
- [x] Create `langchain_agent/api/server.py`
  - [x] `POST /api/analyze` — SSE streaming endpoint
  - [x] `GET /api/stream` — query-param SSE (for mobile)
  - [x] `GET /api/scenarios` — list canned test scenarios
  - [x] `GET /api/db` — live CRM state + last session summary
  - [x] `POST /api/reset` — full demo reset
  - [x] `GET /health` — health check
  - [x] `CORSMiddleware` with `allow_origins=["*"]`
- [x] Run backend, confirm `GET /health` returns `{"status": "ok"}`
