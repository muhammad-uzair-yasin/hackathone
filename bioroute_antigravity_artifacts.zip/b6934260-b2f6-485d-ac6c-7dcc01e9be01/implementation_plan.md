# Implementation Plan — UI Simplification and Shipment Map Integration

We will simplify the news input screen layout by grouping the various input options into tabs. Additionally, we will integrate a live Leaflet map in the shipment detail view to show shipment routes and alternative paths.

## Proposed Changes

### Mobile App Layout & Components

#### [MODIFY] [NewsInputScreen.tsx](file:///home/carlow/Documents/hackathone/mobile/src/screens/NewsInputScreen.tsx)
- Add tab selector state (`activeInputTab`) to switch between:
  1. **Scenarios**: Pre-built scenario picker.
  2. **Text / Voice**: Direct text entry & voice transcription.
  3. **URL / PDF**: Web scraping & PDF document extraction.
- Create a beautiful tab bar to let users toggle input modes.
- Implement an **Active News Input** preview banner that displays when `alertText` is set, allowing users to view, edit, or clear the loaded text from any tab.
- Add CSS styles to support the tab switcher and preview banner.

#### [MODIFY] [ShipmentDetailScreen.tsx](file:///home/carlow/Documents/hackathone/mobile/src/screens/ShipmentDetailScreen.tsx)
- Import `WebView` from `react-native-webview` and `MAP_HTML` from `../constants/mapHtml`.
- Embed a beautiful 260px map container at the top of the detail screen.
- Set up an interactive route display:
  - Default route shown on the map is the active shipment path.
  - Tapping on any alternate route card highlights that alternate route's path on the map dynamically.
- Style the map wrapper using premium glassmorphism.

---

## Verification Plan

### Manual Verification
- Launch Expo app and verify the news input page is clean and uses tabs.
- Load scenario/voice/PDF/URL inputs and check that the active news input preview banner updates immediately.
- Open the Fleet tab, tap a shipment, and verify that the Leaflet map renders the shipment's route.
- Tap alternative routes on the shipment detail screen to verify that the map route updates dynamically.
- Check TypeScript compilation by running `npx tsc --noEmit`.
