# Bug 04 — Pydantic Validation Crash on "All Clear" Path

**Status:** ✅ Resolved
**File affected:** `langchain_agent/schemas.py`

## Problem

When the `impact-analyzer` ran on a news scenario with no hazard (e.g., "Clear skies, no incidents"), it returned `impact_detected: false` but Pydantic required `alternative_routes: list[AlternativeRoute]` and `affected_shipment_id: str` — both of which had no meaningful value. The agent returned an empty list or null, causing `ValidationError` and crashing the pipeline.

## Root Cause

Schema fields were defined as required with no defaults:

```python
# BROKEN
class ImpactAnalysis(BaseModel):
    impact_detected: bool
    affected_shipment_id: str          # crashes when null
    alternative_routes: list[AlternativeRoute]  # crashes when []
    requires_immediate_action: bool    # crashes when missing
```

## Fix

Make conditional fields optional with sensible defaults:

```python
# FIXED
class ImpactAnalysis(BaseModel):
    impact_detected: bool
    affected_shipment_id: str | None = None
    matched_shipment_ids: list[str] = []
    unaffected_shipment_ids: list[str] = []
    alternative_routes: list[AlternativeRoute] = []
    backup_route: str | None = None
    time_to_failure_minutes: int | None = None
    financial_consequence: str = "No financial impact"
    requires_immediate_action: bool = False
    risk_level: str = "LOW"
    display_summary: str
    why_brief: str
```

The orchestrator's conditional `if impact_detected AND requires_immediate_action` check now always has a valid boolean to evaluate.
