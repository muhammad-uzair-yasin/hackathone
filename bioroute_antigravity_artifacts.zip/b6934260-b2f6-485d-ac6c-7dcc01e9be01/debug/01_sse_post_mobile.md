# Bug 01 — SSE POST Not Supported in React Native

**Status:** ✅ Resolved
**File affected:** `langchain_agent/api/server.py`, `mobile/src/hooks/useSSEStream.ts`

## Problem

The web dashboard triggers the agent with `POST /api/analyze`. React Native's `EventSource` polyfill only supports `GET` requests — no request body. Sending the news alert text in a POST body was not possible from mobile.

## Root Cause

The [EventSource spec](https://html.spec.whatwg.org/multipage/server-sent-events.html) only defines `GET`. React Native's `rn-eventsource` and similar polyfills follow this restriction.

## Fix

Added a parallel `GET /api/stream` endpoint that accepts `input` as a URL query parameter:

```python
# server.py — new endpoint added
@app.get("/api/stream")
async def stream_get(input: str = Query(..., description="News alert text")):
    return StreamingResponse(
        run_agent_stream(input_text=input),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )
```

Mobile SSE hook:

```typescript
// useSSEStream.ts
const encoded = encodeURIComponent(alertText);
const url = `${API_URL}/api/stream?input=${encoded}`;
const response = await fetch(url);
const reader = response.body!.getReader();
const decoder = new TextDecoder();

while (true) {
  const { done, value } = await reader.read();
  if (done) break;
  const chunk = decoder.decode(value);
  // Parse "data: {...}\n\n" lines
  parseSSEChunk(chunk).forEach(event => onEvent(event));
}
```

## Why This Works

`fetch` + `ReadableStream` is natively supported in React Native 0.71+ (Hermes engine). This avoids any polyfill dependency while giving us full SSE streaming capability.
