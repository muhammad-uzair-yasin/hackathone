# Bug 03 — FilesystemBackend Path Resolution Failure

**Status:** ✅ Resolved
**File affected:** `langchain_agent/agent.py`

## Problem

Subagents called `read_file("/data/active_shipments.json")` using the virtual path. This worked when uvicorn was launched from `/hackathone/` but failed with `FileNotFoundError` when launched from `/hackathone/langchain_agent/`.

## Root Cause

The `root_dir` was originally set to `"data"` (relative path), which resolves against the process's current working directory — not the location of `agent.py`.

```python
# BROKEN — relative path, cwd-dependent
FilesystemBackend(root_dir="data", virtual_mode=True)
```

## Fix

Use `Path(__file__).parent` to always anchor to the directory containing `agent.py`, regardless of where uvicorn is launched from:

```python
# agent.py
from pathlib import Path

DATA_DIR = Path(__file__).parent / "data"

backend = CompositeBackend(
    default=StateBackend(),
    routes={
        "/data/": FilesystemBackend(
            root_dir=str(DATA_DIR),   # absolute path
            virtual_mode=True,
        ),
    },
)
```

`Path(__file__)` always resolves to `.../hackathone/langchain_agent/agent.py`, so `.parent / "data"` is always `.../hackathone/langchain_agent/data/` regardless of cwd.
