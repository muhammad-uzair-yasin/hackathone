# Bug 05 — Action Planner Selecting Blocked Route

**Status:** ✅ Resolved
**File affected:** `langchain_agent/agent.py` (ACTION_PLANNER_PROMPT), `langchain_agent/data/active_shipments.json`

## Problem

In early testing, the `action-planner` selected Alternative A3 (Coastal Route via Thatta), which still passes through Hyderabad West Bypass — the exact location of the N-5 blockage. The selected route would not have saved the shipment.

## Root Cause

Two issues:
1. The prompt didn't explicitly instruct the planner to *reject* routes sharing the blocked corridor
2. The `notes` field in `active_shipments.json` alternatives didn't flag route overlap clearly enough

## Fix — Prompt Update

Added explicit rejection rule to `ACTION_PLANNER_PROMPT`:

```python
ACTION_PLANNER_PROMPT = """
...
## Rules
- Reject alternatives that still use the blocked corridor.
- Prefer cold-vault handoff for temperature-critical cargo in heat.
- Output ONLY valid JSON.
"""
```

## Fix — Data Update

Updated `notes` field per alternative route to clearly state overlap:

```json
{
  "id": "A3",
  "name": "Coastal Route via Thatta",
  "eta_minutes": 95,
  "notes": "AVOID: Passes through Hyderabad West Bypass, same blockage zone as N-5"
},
{
  "id": "A1",
  "name": "M-9 Thatta Bypass",
  "eta_minutes": 52,
  "notes": "RECOMMENDED: Fully avoids N-5 corridor. Cold-vault at Hyderabad Hub."
}
```

After the fix, the planner correctly selected A1 (M-9 Thatta Bypass) in all subsequent test runs.
