# Bug 06 — Reset Not Clearing summary.md

**Status:** ✅ Resolved
**File affected:** `langchain_agent/tools.py`

## Problem

After clicking "Reset Demo", the web dashboard still showed the previous run's outcome (Emergency Reroute) in the before-state panel, because `summary.md` still contained the old pipeline JSON.

## Fix

`reset_active_shipments_to_baseline()` now also calls `clear_summary_file()`:

```python
def reset_active_shipments_to_baseline() -> bool:
    if not BASELINE_SHIPMENTS_FILE.exists():
        return False
    with open(BASELINE_SHIPMENTS_FILE, "r") as f:
        data = json.load(f)
    data["last_updated"] = datetime.now(timezone.utc).isoformat()
    with open(SHIPMENTS_FILE, "w") as f:
        json.dump(data, f, indent=2)
    clear_summary_file()   # ← added
    return True
```

---

# Bug 07 — Orchestrator Echoing Subagent Output Verbatim

**Status:** ✅ Resolved
**File affected:** `langchain_agent/agent.py` (ORCHESTRATOR_SYSTEM_PROMPT)

## Problem

The orchestrator was copying `display_summary` from each subagent into its own coordinator messages, making the trace panel redundant and verbose.

## Fix

Added strict voice constraints to the orchestrator prompt:

```
## Coordinator voice (you only)
- Speak in short plain sentences (≤20 words). No markdown, no bold, no tables.
- Maximum 5 coordinator messages for the whole run.
- After each subagent: say what you learned in YOUR OWN WORDS, then what you call next.
- Do NOT copy display_summary or why_brief from subagents verbatim.
- Say "received the alert" at most once.
```

---

# Bug 08 — 429 Rate Limit During Multi-Step Run

**Status:** ✅ Resolved
**File affected:** `langchain_agent/agent.py` (MIDDLEWARE)

## Problem

Rapid sequential calls to all 4 subagents + 3 orchestrator tools hit Anthropic's rate limit. The `ModelRetryMiddleware` initial delay of 0.5s was too short; the retried request also got 429'd.

## Fix

Increased initial delay from 0.5s to 2.0s with 2× backoff:

```python
ModelRetryMiddleware(
    max_retries=3,
    initial_delay=2.0,    # was 0.5
    backoff_factor=2.0,
    max_delay=30.0,
)
```

Worst-case total wait before failure: 2s + 4s + 8s = **14 seconds** across 3 retries.
After this fix, the entire 4-subagent pipeline completes reliably on the hackathon API tier.
