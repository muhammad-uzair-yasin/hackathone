# Bug 02 — Agent Re-initialized on Every File Save

**Status:** ✅ Resolved
**File affected:** `langchain_agent/agent.py`

## Problem

Running the backend with `uvicorn --reload` (needed for hot reload during dev) caused the LangChain agent to be rebuilt from scratch every time any `.py` file was saved. Each `create_deep_agent()` call took 2–3 seconds, making the development loop painful.

## Root Cause

`--reload` spawns a new process on file change. Without caching, the module-level `create_deep_agent()` call ran on every import.

## Fix

Singleton pattern — agent is built once and cached globally:

```python
# agent.py

_agent = None

def build_agent():
    return create_deep_agent(
        model=claude_fast,
        name="bioroute-orchestrator",
        tools=[update_crm_tool, notify_tool, write_summary_tool],
        subagents=SUBAGENTS,
        system_prompt=ORCHESTRATOR_SYSTEM_PROMPT,
        middleware=MIDDLEWARE,
        backend=backend,
    )

def get_agent():
    global _agent
    if _agent is None:
        _agent = build_agent()
    return _agent
```

The server imports `get_agent()` not `build_agent()`, so rebuilds only happen when the process is new (true restarts), not on every reload event.
