# BioRoute Cold-Chain Agent — Final Walkthrough

> **Hackathon:** Antigravity: The Content-to-Action Agent Design Framework
> **Project:** BioRoute Cold-Chain — Autonomous AI Logistics Protection
> **Submission Date:** 2026-05-20

---

## What Was Built

A full-stack autonomous AI system that:
1. **Ingests** unstructured news/weather alerts (text)
2. **Reasons** through a 4-subagent LangChain pipeline to identify affected medical shipments
3. **Acts** by physically updating the CRM database and generating hospital notifications
4. **Visualizes** the before/after state change on a web dashboard and React Native mobile app

---

## Build Phases Summary

| Phase | What | Artifact |
|-------|------|---------|
| Phase 1 | FastAPI backend with SSE streaming | [phase1_backend_setup.md] |
| Phase 2 | Data layer, mock CRM, Pydantic schemas | [phase2_data_layer.md] |
| Phase 3 | LangChain Deep Agents (4 subagents + orchestrator) | [phase3_langchain_agents.md] |
| Phase 4 | Web dashboard (HTML/JS/CSS) | [phase4_web_dashboard.md] |
| Phase 5 | React Native mobile app (7 screens) | [phase5_mobile_app.md] |
| Debug | Issues encountered & resolved (8 bugs) | [debugging_log.md] |

---

## Confirmed Working Pipeline — Session REQ-153109

**Input alert:**
> "Multi-vehicle collision blocks N-5 National Highway near Hyderabad. Temperatures at 42–44°C. Jamshoro route completely closed."

**Pipeline execution (2026-05-18T15:31 UTC):**

```
Step 1 — hazard-extractor:
  → hazard_detected: true
  → location: N-5 National Highway, Hyderabad West Bypass
  → severity_level: CRITICAL
  → temperature_celsius: 42.0

Step 2 — fleet-scout:
  → total_active: 1
  → SHP-882: Insulin on N-5 Karachi → Jamshoro (ETA 40 min)

Step 3 — impact-analyzer:
  → impact_detected: true
  → affected_shipment_id: SHP-882
  → time_to_failure_minutes: 20
  → financial_consequence: $50,000 + critical insulin shortage at teaching hospital
  → requires_immediate_action: true

Step 4 — action-planner:
  → selected_route: M-9 Thatta Bypass (Alternative A1)
  → Rationale: Only route fully avoiding N-5 + cold-vault handoff at Hyderabad

Step 5 — update_crm_tool:
  BEFORE: SHP-882 | N-5 Karachi→Jamshoro | In Transit (On Time)
  AFTER:  SHP-882 | M-9 Thatta Bypass    | Emergency Reroute

Step 6 — notify_tool:
  → NOTIF-SHP-882-203109 sent to Liaquat University Hospital Administration
  → Urgency: IMMEDIATE | Channels: email + sms

Step 7 — write_summary_tool:
  → summary.md written (session REQ-153109, status: completed)
```

**Result:** Insulin shipment rerouted within 20-minute spoilage window. Hospital notified. Full audit trail in `summary.md`.

---

## Deliverables Checklist

- [x] **LangChain Multi-Agent Backend** — 4 subagents, orchestrator, 3 tools
- [x] **FastAPI Server** — SSE streaming, 6 endpoints
- [x] **Mock CRM** — `active_shipments.json` with Pakistani routes (N-5, M-9, M-3)
- [x] **Action Simulation** — `update_crm_tool` physically writes before→after state
- [x] **Notification Simulation** — `notify_tool` writes to `notifications.json`
- [x] **Audit Log** — `write_summary_tool` writes `summary.md` with embedded pipeline JSON
- [x] **Retry Logic** — `ModelRetryMiddleware` + `ToolRetryMiddleware` (3 retries, exponential backoff)
- [x] **Web Link & PDF Text Extractor** ⭐ — extract text from website URLs or uploaded PDFs and load them as news inputs in the app
- [x] **Web App Dashboard** — SSE streaming, route map, before/after panels
- [x] **React Native Mobile App** — 7 screens (Expo, TypeScript)
- [x] **README.md** — full setup & quick-start guide
- [x] **PROJECT_SCOPE.md** — BRD, architecture, grading rubric alignment


---

## File Structure (Final)

```
hackathone/
├── PROJECT_SCOPE.md
├── README.md
├── pyproject.toml
├── .python-version
├── test_stream.py / test_stream2.py / test_stream3.py
├── langchain_agent/
│   ├── __init__.py
│   ├── llm.py
│   ├── agent.py              ← 4 subagents + orchestrator
│   ├── tools.py              ← update_crm_tool, notify_tool, write_summary_tool
│   ├── schemas.py            ← Pydantic schemas for all 4 agent outputs
│   └── api/
│       ├── __init__.py
│       └── server.py         ← FastAPI + SSE (6 endpoints)
│   └── data/
│       ├── active_shipments.json        ← Live CRM (mutated by agent)
│       ├── active_shipments_baseline.json  ← Pristine copy for reset
│       ├── business_context.md
│       ├── news_scenarios.json
│       ├── notifications.json           ← Populated after agent run
│       ├── summary.md                   ← Agent run audit log
│       └── generate_news.py
├── webapp/
│   ├── index.html
│   ├── app.js
│   ├── map.js
│   └── styles.css
└── mobile/
    ├── App.tsx
    ├── app.json / package.json / tsconfig.json
    ├── .env.example / .env
    └── src/
        ├── screens/ (7 screens)
        ├── api/
        ├── hooks/
        ├── theme/
        ├── types/
        ├── components/
        └── utils/
```

---

## Grading Rubric Alignment

| Criteria | How It's Met |
|----------|-------------|
| **Insight Extraction** | `hazard-extractor` returns structured `HazardExtraction` JSON — not summaries |
| **Impact Analysis** | `impact-analyzer` calculates `time_to_failure_minutes`, `financial_consequence` |
| **Action Generation** | `action-planner` picks best of 4 alternatives with written rationale |
| **Action Simulation** ⭐ | `update_crm_tool` physically writes `active_shipments.json` before→after |
| **Outcome Visualization** | Web + mobile both show before/after state with toggle |
| **Multi-step Reasoning** | 4 sequential subagents with structured state passing |
| **Google Antigravity** ⭐ | Used throughout as IDE — all artifacts generated by Antigravity |
| **Traceable Decisions** | `summary.md` + `notifications.json` + mobile AgentScreen |
| **Robustness** | Exponential backoff, graceful all-clear path, demo reset |
| **Mobile App** ⭐ | 7-screen React Native Expo app (TypeScript) |

---

## How to Run

```bash
# Terminal 1 — Backend
uv run uvicorn langchain_agent.api.server:app --reload --port 8000

# Terminal 2 — Mobile
cd mobile && npm start

# Web Dashboard — open in browser
xdg-open webapp/index.html
```

---

## Phase 7 Updates — UI Simplification & interactive Map

1. **Tab Switcher on NewsInputScreen**:
   - Organizes pre-built **Scenarios**, **Text/Voice** input, and **URL/PDF** extraction into beautiful, distinct tabs.
   - Reduces vertical scrolling clutter on the homepage.
   - Shows a **🎯 Active News Input Preview** banner that is universally accessible, allowing users to edit, clear, and review active input text from any tab before launching investigations.

2. **Interactive Leaflet Map on ShipmentDetailScreen**:
   - Replaces text lists of coordinates with a live Leaflet map rendering the active route.
   - Renders alternative routes on-demand: tapping any alternative route card highlights its path dynamically on the map and animates the truck 🚛 along it.
   - Styled with clean glassmorphism to look cohesive with the app's premium dark aesthetics.

