# Phase 1 — Project Scaffold & FastAPI Backend

> **Status:** ✅ Complete
> **Files created:** `pyproject.toml`, `.python-version`, `langchain_agent/api/server.py`, `langchain_agent/__init__.py`

---

## What Was Built

### Project Foundation

Set up the Python project using `uv` as the package manager for fast dependency resolution. Python 3.13 was selected (`.python-version`). Key dependencies added to `pyproject.toml`:

```toml
[project]
name = "hackathone"
dependencies = [
    "deepagents",
    "fastapi",
    "uvicorn[standard]",
    "langchain",
    "langchain-anthropic",
    "python-dotenv",
]
```

### FastAPI Bridge (`langchain_agent/api/server.py`)

The FastAPI server acts as the bridge between the frontend and the LangChain agent. It uses **Server-Sent Events (SSE)** so the frontend can receive live streaming updates from the agent as it reasons through each step.

**Endpoints built:**

| Method | Path | Purpose |
|--------|------|---------|
| `POST` | `/api/analyze` | Main agent trigger — streams SSE events |
| `GET` | `/api/stream` | Query-param SSE for React Native |
| `GET` | `/api/scenarios` | Returns list of canned news scenarios |
| `GET` | `/api/db` | Returns live CRM state (shipments) |
| `POST` | `/api/reset` | Resets demo data to baseline |
| `GET` | `/health` | Health check |

**Key design decision — SSE over WebSockets:**

SSE was chosen over WebSockets because:
1. It's unidirectional (server → client) which matches the agent output pattern
2. Works natively with React Native `EventSource` polyfill
3. Simpler to implement and debug than WS for demo purposes

### CORS Configuration

`CORSMiddleware` added with `allow_origins=["*"]` to enable both the local web app (file:///) and the Expo mobile app (local IP) to connect without CORS errors.

---

## How to Run

```bash
# From project root
uv run uvicorn langchain_agent.api.server:app --reload --port 8000
```

Server available at: `http://localhost:8000`

---

## Issues Encountered & Resolved

> [!NOTE]
> **SSE encoding**: FastAPI's `StreamingResponse` requires careful handling of the `data:` prefix and `\n\n` event separator. Each SSE event was formatted as:
> ```
> data: {"type": "agent_step", "content": "..."}\n\n
> ```

> [!NOTE]
> **Reload issues**: `--reload` mode causes the LangChain agent to be re-initialized on every file save. Solved with a singleton pattern in `agent.py` (`get_agent()` returns cached instance).
