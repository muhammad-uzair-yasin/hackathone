# Phase 2 — Data Layer & Pydantic Schemas

> **Status:** ✅ Complete
> **Files created:** `langchain_agent/data/active_shipments.json`, `langchain_agent/data/active_shipments_baseline.json`, `langchain_agent/data/business_context.md`, `langchain_agent/data/news_scenarios.json`, `langchain_agent/schemas.py`

---

## What Was Built

### Mock CRM Database (`active_shipments.json`)

The mock CRM stores active medical shipments with full Pakistani road network routes. Each shipment has:

- **Primary route** with GPS-accurate stops (lat/lng)
- **4 alternative routes** (A1–A4) with ETAs and notes — the action-planner picks the best one
- Temperature thresholds, cargo type, criticality tier
- Destination hospital

**Key design decision — 4 alternatives per shipment:**

The original scope only had 1 backup facility. Upgraded to 4 alternatives to force the action-planner to *reason* about which route is best, not just pick the only option. This makes the agent reasoning genuinely demonstrable.

**Real Pakistani routes used:**

| Route ID | Name | Use Case |
|----------|------|---------|
| Primary | N-5 Karachi → Jamshoro | Main highway |
| A1 | M-9 Thatta Bypass | Best alternate (avoids N-5) |
| A2 | Indus Highway West | Longer but fully clear |
| A3 | Coastal Route via Thatta | Scenic but slow |
| A4 | Hyderabad Urban Bypass | Urban fallback |

### Baseline Copy (`active_shipments_baseline.json`)

A pristine copy of the original shipment state. The `/api/reset` endpoint restores `active_shipments.json` from this file so the demo can be re-run cleanly.

### Business Context (`business_context.md`)

Rules injected into agent prompts to ground decisions:

```
Max safe idle time at temp > 38°C: 45 minutes
Cargo spoilage cost: $50,000 per shipment
Rerouting trigger: Blocked route + temp > 38°C + idling
Notification policy: Immediate email/SMS to destination hospital
```

### News Scenarios (`news_scenarios.json`)

6 pre-built test scenarios covering:
1. Heatwave + traffic collision on N-5 (**primary demo**)
2. Flash flooding on M-9
3. Political strike blocking urban routes
4. Truck breakdown on highway
5. Clear weather — no action required (tests "all clear" path)
6. Multiple simultaneous hazards

### Pydantic Schemas (`schemas.py`)

Four structured output schemas enforced by `deepagents`:

```python
class HazardExtraction(BaseModel):
    hazard_detected: bool
    location: str
    affected_districts: list[str]
    hazard_type: str
    severity_level: str  # LOW/MEDIUM/HIGH/CRITICAL
    affected_routes: list[str]
    temperature_celsius: float | None
    estimated_duration_minutes: int | None
    display_summary: str
    why_brief: str

class FleetScoutOutput(BaseModel):
    total_active: int
    active_shipments: list[ShipmentSummary]
    display_summary: str
    why_brief: str

class ImpactAnalysis(BaseModel):
    impact_detected: bool
    affected_shipment_id: str | None
    alternative_routes: list[AlternativeRoute]  # All 4 from CRM
    time_to_failure_minutes: int | None
    financial_consequence: str
    risk_level: str
    requires_immediate_action: bool
    display_summary: str
    why_brief: str

class ActionPlan(BaseModel):
    selected_route_name: str
    selected_alternative_id: str
    database_simulation_payload: CRMPayload
    notification_simulation: NotificationPayload
    urgency: str
    display_summary: str
    why_brief: str
```

---

## Design Decisions

> [!IMPORTANT]
> **Structured outputs over free text**: Using Pydantic `response_format` on each subagent forces the LLM to return machine-parseable JSON rather than markdown prose. This is what enables the SSE frontend to render each step as a structured card rather than raw text.

> [!NOTE]
> **`display_summary` + `why_brief` on every schema**: Every agent output includes a 1-sentence human summary (`display_summary`) and a ≤15-word justification (`why_brief`). These two fields drive the mobile app's step-by-step trace UI without additional parsing logic.
