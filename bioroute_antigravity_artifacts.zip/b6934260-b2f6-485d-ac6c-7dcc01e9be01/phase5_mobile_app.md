# Phase 5 — React Native Mobile App (mobile/)

> **Status:** ✅ Complete
> **Framework:** React Native + Expo (TypeScript)
> **Files created:** `mobile/App.tsx`, `mobile/src/screens/*` (7 screens), `mobile/src/api/`, `mobile/src/hooks/`, `mobile/src/theme/`, `mobile/src/components/`, `mobile/src/types/`

---

## What Was Built

The mobile app is a **React Native (Expo)** application that connects to the same FastAPI backend via the `GET /api/stream` SSE endpoint. It provides a polished, production-quality mobile UI for the full BioRoute pipeline.

---

## Screen Architecture

### Navigation Structure (`App.tsx`)

```
Stack Navigator
├── IngestionDashboard   (Home screen)
│   ├── → NewsInputScreen
│   └── → AIDecisionEngine (after analysis starts)
│       └── → OutcomeVisualization
├── FleetScreen
│   └── → ShipmentDetailScreen
└── AgentScreen
```

---

### Screen 1 — `IngestionDashboard.tsx` (18.9 KB)

The home screen and primary entry point.

**Features:**
- **Active shipments overview card** — live count + status badges pulled from `/api/db`
- **"Ingest Unstructured Alert" button** — navigates to `NewsInputScreen`
- **Recent runs list** — shows last session summary from `/api/db`
- Animated header with BioRoute logo and real-time clock
- Pull-to-refresh updates shipment status

---

### Screen 2 — `NewsInputScreen.tsx` (17.2 KB)

News alert input with pre-canned scenarios.

**Features:**
- Scenario dropdown (fetched from `/api/scenarios`)
- Multi-line textarea for manual input
- Character count indicator
- **"Analyze & Protect Supply Chain"** CTA button (primary demo action)
- Trigger animation on submit before navigating to AI Decision Engine

---

### Screen 3 — `AIDecisionEngine.tsx` (13.9 KB)

Live agent reasoning trace — the core demo screen.

**Features:**
- **SSE streaming** via `GET /api/stream?input=...`
- Timeline stepper with 4 steps (one per subagent)
- Each step card shows:
  - Step number + colored icon
  - `display_summary` text
  - `why_brief` chip (rationale badge)
  - Expandable raw JSON section
- **Progress bar** tracking pipeline completion (0–100%)
- Smooth card slide-in animation as each step streams in
- Auto-scroll to latest step
- Completion → **"View Outcome"** button appears

**SSE implementation in React Native:**

```typescript
// React Native doesn't support EventSource natively for GET with body
// Used custom SSE hook with fetch + ReadableStream
const useSSEStream = (url: string) => {
  const [events, setEvents] = useState<SSEEvent[]>([]);
  useEffect(() => {
    const reader = fetch(url).then(r => r.body!.getReader());
    // Decode and parse SSE chunks...
  }, [url]);
  return events;
};
```

---

### Screen 4 — `OutcomeVisualization.tsx` (10.4 KB)

Before/After state comparison — the outcome proof screen.

**Features:**
- **Toggle switch**: "Before Alert" / "After AI Execution"
- **Before state card:**
  - SHP-882 → Highway: N-5 Karachi → Jamshoro → Status: In Transit (On Time) 🟢
- **After state card:**
  - SHP-882 → Highway: M-9 Thatta Bypass → Status: Emergency Reroute 🔴
  - New destination: Hyderabad Cold-Vault
- **Notification log panel** — shows hospital notification with IMMEDIATE urgency badge
- **"Acknowledge & Reset Demo"** button — calls `/api/reset`
- Confetti animation on first view (positive outcome reinforcement)

---

### Screen 5 — `FleetScreen.tsx` (7.4 KB)

Full fleet overview.

**Features:**
- List of all active shipments with cargo type, route, status, ETA
- Severity color coding (CRITICAL / HIGH / MEDIUM / OK)
- Tap → `ShipmentDetailScreen`

---

### Screen 6 — `ShipmentDetailScreen.tsx` (3.5 KB)

Individual shipment detail view.

- Route stops list with ETA
- Temperature threshold indicator
- Cargo type + value
- Alternative routes preview

---

### Screen 7 — `AgentScreen.tsx` (6.4 KB)

Last agent run audit view.

- Session ID + timestamp
- Step-by-step summary of last pipeline run
- Link to raw `summary.md` content

---

## Supporting Infrastructure

### `mobile/src/api/`

API client wrapping all backend endpoints with TypeScript return types. Handles:
- Base URL from `EXPO_PUBLIC_API_URL` env var
- Timeout handling
- Error normalization

### `mobile/src/hooks/`

Custom hooks:
- `useSSEStream(url)` — SSE streaming hook
- `useShipments()` — polls `/api/db` every 5s
- `useScenarios()` — fetches `/api/scenarios` once

### `mobile/src/theme/`

Design tokens:
- Color palette (dark mode, severity colors)
- Typography scale (Inter font via Expo Google Fonts)
- Spacing / border radius tokens

### `mobile/src/types/`

TypeScript interfaces matching Pydantic schemas from backend:
```typescript
interface HazardExtraction { ... }
interface ImpactAnalysis { ... }
interface ActionPlan { ... }
interface SSEEvent { type: string; data: Record<string, unknown> }
```

---

## Running the Mobile App

```bash
cd mobile

# Install dependencies (first time)
npm install

# Set environment
cp .env.example .env
# Edit .env: EXPO_PUBLIC_API_URL=http://192.168.x.x:8000

# Start Expo
npm start
# → Press 'a' for Android, 'i' for iOS, 'w' for browser
```

> [!NOTE]
> Use your machine's local IP address (not `localhost`) in `EXPO_PUBLIC_API_URL` so the physical phone can reach the backend over the local network.
