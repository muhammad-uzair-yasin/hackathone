import httpx
from reportlab.pdfgen import canvas
import io
import os

def test_extract_pdf():
    # 1. Create a simple PDF in memory
    pdf_buffer = io.BytesIO()
    p = canvas.Canvas(pdf_buffer)
    p.drawString(100, 750, "BIOROUTE SYSTEM ADVISORY")
    p.drawString(100, 720, "Alert: Heavy rainfall near Thatta Bypass has flooded parts of N-5")
    p.drawString(100, 700, "All cold-chain transport SHP-882 must reroute immediately.")
    p.showPage()
    p.save()
    
    pdf_buffer.seek(0)
    pdf_data = pdf_buffer.getvalue()
    
    # 2. Upload to the FastAPI endpoint
    print("Uploading PDF to /api/extract/pdf...")
    files = {"file": ("advisory.pdf", pdf_data, "application/pdf")}
    
    resp = httpx.post("http://localhost:8001/api/extract/pdf", files=files)
    print("Status code:", resp.status_code)
    print("Response JSON:")
    import json
    print(json.dumps(resp.json(), indent=2))

if __name__ == "__main__":
    test_extract_pdf()
