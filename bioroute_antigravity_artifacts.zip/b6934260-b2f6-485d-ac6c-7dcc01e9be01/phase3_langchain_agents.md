# Phase 3 — LangChain Deep Agents Multi-Agent System

> **Status:** ✅ Complete
> **Files created:** `langchain_agent/llm.py`, `langchain_agent/tools.py`, `langchain_agent/agent.py`

---

## What Was Built

### LLM Client (`llm.py`)

`claude_fast` is the shared LLM instance used by all 4 subagents and the orchestrator. Configured with Anthropic API key from environment variables.

### The 4-Subagent Pipeline (`agent.py`)

Each subagent is a specialist with a narrow, well-defined role. The orchestrator never skips steps and always passes the **full raw alert text** — not pre-parsed JSON — to each downstream agent so they reason independently.

```
hazard-extractor  →  fleet-scout  →  impact-analyzer  →  action-planner
      ↓                  ↓                  ↓                   ↓
 HazardExtraction  FleetScoutOutput   ImpactAnalysis        ActionPlan
```

#### Subagent 1 — `hazard-extractor`

**Role:** Reads only raw alert text. Extracts structured hazard facts.
**Key constraint:** Must NOT read any files. Facts-only extraction.

```
System Prompt Rules:
- Use real Pakistani routes (N-5, M-3, M-9, Murree Rd, etc.)
- Never use placeholder names like "District 4" or "Highway 9"
- Output ONLY valid JSON (HazardExtraction schema)
```

#### Subagent 2 — `fleet-scout`

**Role:** Reads `active_shipments.json`. Lists every truck currently on the road.
**Key constraint:** Must NOT decide who is affected — that's the analyzer's job.

#### Subagent 3 — `impact-analyzer`

**Role:** Cross-references raw alert with CRM. Decides which shipment is at risk and why.
**Key constraint:** Must NOT use hazard-extractor JSON as input — must reason fresh from the news text.

```
Output includes:
- All 4 alternative routes for the affected shipment
- time_to_failure_minutes (critical for urgency)
- financial_consequence + medical_consequence
- requires_immediate_action flag
```

#### Subagent 4 — `action-planner`

**Role:** Picks the single best alternative route from the 4 options. Generates CRM payload + notification draft.
**Selection logic:**
- Reject routes that still pass through the blocked corridor
- Prefer cold-vault handoff stops for temperature-critical cargo in heatwave
- Output `selected_alternative_id` (A1–A4) + exact `new_route` name

---

### Orchestrator System Prompt (7-Step Workflow)

The orchestrator is given a strict, ordered workflow it must follow:

```
1. write_todos — announce what steps will be run
2. task('hazard-extractor', FULL raw alert text)
3. If hazard_detected → task('fleet-scout', FULL raw alert)
4. If hazard_detected → task('impact-analyzer', raw alert + fleet JSON)
5. If impact_detected AND high risk → task('action-planner', raw alert + impact JSON)
6. If urgency IMMEDIATE/SOON → update_crm_tool() then notify_tool()
7. write_summary_tool() LAST — always, even for all-clear
```

**Coordinator voice constraints:**
- Max 5 coordinator messages for entire run (prevents verbose output)
- ≤20 words per message
- Cannot copy `display_summary`/`why_brief` verbatim from subagents

---

### Orchestrator Tools (`tools.py`)

#### `update_crm_tool` — The Critical Action Simulation

This is the most important tool — it physically modifies `active_shipments.json` to prove the agent took a real action:

```python
# Before-state snapshot taken first
before_state = _shipment_route_snapshot(record)

# Route swap: replaces primary route[] with chosen alternative's stops[]
_apply_alternative_route(record, new_route)
record["current_status"] = new_status  # "Emergency Reroute"

# Write to disk
json.dump(data, f, indent=2)

# After-state snapshot for diff
after_state = _shipment_route_snapshot(record)

# Returns: {before_state, after_state, message}
```

**Route swap logic:** `_apply_alternative_route()` matches the `new_route` name against `alternative_routes[].name` or `alternative_routes[].id` (e.g., "A1"), then copies that alternative's `stops[]` array into the shipment's `route[]` field.

#### `notify_tool` — Notification Simulation

Appends a structured notification record to `notifications.json` with:
- `notification_id`: `NOTIF-SHP-882-HHMMSS`
- Channels: `["email", "sms"]`
- `status`: `"SENT (simulated)"`
- Full message draft

#### `write_summary_tool` — Run Audit Log

Writes `summary.md` with human-readable summary + embedded HTML comment containing full pipeline JSON (parseable by `/api/db` endpoint for frontend).

---

### Middleware & Retry Logic

```python
MIDDLEWARE = [
    ModelRetryMiddleware(
        max_retries=3,
        initial_delay=2.0,
        backoff_factor=2.0,
        max_delay=30.0,
    ),
    ToolRetryMiddleware(
        max_retries=3,
        initial_delay=1.0,
        backoff_factor=2.0,
        max_delay=30.0,
        jitter=True,
        on_failure="return_message",
    ),
]
```

Handles 429 rate limits (Anthropic), network timeouts, and malformed tool outputs gracefully without crashing the demo.

### CompositeBackend

```python
backend = CompositeBackend(
    default=StateBackend(),
    routes={
        "/data/": FilesystemBackend(
            root_dir=str(DATA_DIR),
            virtual_mode=True,
        ),
    },
)
```

Allows subagents to `read_file("/data/active_shipments.json")` using a virtual path that maps to the real `langchain_agent/data/` directory, regardless of working directory.

---

## Verification

```bash
# Full end-to-end test
curl -X POST http://localhost:8000/api/analyze \
  -H "Content-Type: application/json" \
  -d '{"input": "Severe heatwave in Hyderabad. N-5 blocked by collision near Jamshoro."}'

# Check CRM was updated
curl http://localhost:8000/api/db

# Expected in active_shipments.json:
# SHP-882: current_status = "Emergency Reroute"
#          route_name = "M-9 Thatta Bypass"
#          destination = "Hyderabad Cold-Vault"
```

> [!IMPORTANT]
> **Confirmed working run (Session REQ-153109, 2026-05-18):** SHP-882 was successfully rerouted from N-5 to M-9 Thatta Bypass within 20-minute spoilage window. Notification sent to Liaquat University Hospital Administration. Full pipeline trace in `langchain_agent/data/summary.md`.
