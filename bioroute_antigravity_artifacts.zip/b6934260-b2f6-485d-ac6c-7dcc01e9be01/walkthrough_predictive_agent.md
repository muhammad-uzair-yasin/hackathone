# Predictive Risk Agent — Completed Walkthrough

## What Was Built

A **completely independent** Predictive Risk Agent for BioRoute — zero shared state with the main rerouting agent. It proactively predicts cold-chain breaches before they happen using a 3-stage LangChain deep agent pipeline.

---

## Architecture Overview

```
Mobile (Predict Tab)
       │
       ├── GET /api/predict/stream    ← SSE live stream (XHR)
       ├── POST /api/predict/schedule ← set/stop auto schedule
       ├── GET /api/predict/schedule  ← countdown to next run
       └── GET /api/predictions       ← read latest results
              │
              ▼
    prediction_agent.py  (create_deep_agent)
              │
    ┌─────────┴──────────────────┐
    │  bioroute-prediction-       │
    │  orchestrator               │  ← same pattern as main orchestrator
    └─────────┬──────────────────┘
              │
    ┌─────────▼──────────┐
    │  sensor-analyst     │  → SensorAnalysisOutput (Pydantic)
    │  reads: active_shipments.json + risk_context.json
    └─────────┬──────────┘
              │
    ┌─────────▼──────────┐
    │  pattern-matcher   │  → PatternAnalysisOutput (Pydantic)
    │  reads: breach_patterns.json + sensor output
    └─────────┬──────────┘
              │
    ┌─────────▼──────────┐
    │  risk-scorer       │  → PredictionOutput (Pydantic)
    │  combines both → final score 0–100 per shipment
    └─────────┬──────────┘
              │
    write_predictions_tool (@tool) → predictions.json
```

---

## Files Created / Modified

| File | Action | Description |
|---|---|---|
| `langchain_agent/prediction_agent.py` | **Created** (rewritten) | Full deep agent — identical pattern to `agent.py` |
| `langchain_agent/prediction_schemas.py` | **Created** | Pydantic schemas: `SensorAnalysisOutput`, `PatternAnalysisOutput`, `PredictionOutput` |
| `langchain_agent/data/risk_context.json` | **Created** | Simulated live sensor/telemetry data |
| `langchain_agent/data/breach_patterns.json` | **Created** | Historical cargo thresholds per type |
| `langchain_agent/data/predictions.json` | **Created** | Output store (updated each run) |
| `langchain_agent/api/server.py` | **Modified** | Added 5 new endpoints + `_run_prediction_stream()` |
| `mobile/src/screens/PredictionScreen.tsx` | **Created** | Full mobile screen |
| `mobile/src/components/BottomTabBar.tsx` | **Modified** | Added 🟣 Predict tab |
| `mobile/App.tsx` | **Modified** | Wired PredictionScreen into nav |

---

## Architecture Parity with `agent.py`

| Pattern | `agent.py` | `prediction_agent.py` |
|---|---|---|
| Framework | `create_deep_agent()` | `create_deep_agent()` ✅ |
| LLM | `claude_fast` (Pollinations) | `claude_fast` (Pollinations) ✅ |
| Subagent declaration | `SUBAGENTS` list | `PRED_SUBAGENTS` list ✅ |
| Response validation | Pydantic `response_format=` | Pydantic `response_format=` ✅ |
| Retry middleware | `ModelRetryMiddleware` + `ToolRetryMiddleware` | Same ✅ |
| Backend | `CompositeBackend + FilesystemBackend` | `pred_backend` same setup ✅ |
| Tool | `@tool` write_summary_tool | `@tool` write_predictions_tool ✅ |
| Singleton | `get_agent()` | `get_prediction_agent()` ✅ |

---

## Streaming — Same Pattern as Main Agent

```
GET /api/predict/stream  →  StreamingResponse (SSE)
                             │
                             ├── agent.astream_events(v3)
                             ├── consume_coordinator()   → PRED_COORDINATOR events
                             ├── consume_tool_calls()    → TOOL_CALL / TOOL_RESULT
                             └── consume_subagents()     → SUBAGENT_START / MSG / DONE
                             │
                             └── PRED_COMPLETE { predictions[], overall_fleet_risk }
```

Mobile receives via `XHR.onprogress` (React Native SSE pattern):
```
PRED_CONNECTED → SUBAGENT_START (sensor-analyst) → SUBAGENT_MSG
→ SUBAGENT_DONE → SUBAGENT_START (pattern-matcher) → ...
→ SUBAGENT_DONE → SUBAGENT_START (risk-scorer) → SUBAGENT_DONE
→ TOOL_CALL (write_predictions_tool) → TOOL_RESULT → PRED_COMPLETE
```

---

## API Endpoints Added

| Method | Endpoint | Use |
|---|---|---|
| `GET` | `/api/predict/stream` | SSE live pipeline stream (mobile) |
| `POST` | `/api/predict` | Blocking trigger (background scheduler) |
| `POST` | `/api/predict/schedule` | Set interval: 0/1/5/15/30/60 min |
| `GET` | `/api/predict/schedule` | Read schedule state + next_run_at |
| `GET` | `/api/predictions` | Read latest saved predictions |
| `GET` | `/api/risk-context` | Retrieve the current live risk context data |
| `POST` | `/api/risk-context` | Update/save the live risk context variables |

---

## Mobile UI Features (Predict Tab 🟣)

- **Sub Tab Navigation** — Seamlessly toggle between **Dashboard** (visual risk scoring, schedule, history chart) and **Edit Risk Data** (real-time form variables editor).
- **Risk Context Editor** — Form controls enabling operator/demo users to override live environment and logistics variables:
  - **Environment Variables**: Ambient Temperature (°C), Humidity (%), Weather Condition text, and 2-Hour Weather Forecast.
  - **Road & Traffic Status**: Traffic Level selectors (LOW, MEDIUM, HIGH), Average Route Delay (min), Thatta Checkpoint Wait (min), and Road Quality selectors (GOOD, FAIR, POOR).
  - **Infrastructure Stability**: Power Grid Stability (STABLE, UNSTABLE) and Route Fuel Availability (AVAILABLE, LIMITED, CRITICAL).
  - **Vehicle Telemetry**: Sectioned telemetry parameters per active shipment ID (SHP-882, SHP-901, SHP-915, SHP-928) for Idle Minutes, Engine Temperature (°C), and Refrigeration Unit status (ACTIVE, WARNING, FAILED).
  - **Apply Button**: Instantly updates `risk_context.json` via the REST API to trigger downstream updates on the next AI agent run.
- **Schedule Configurator** — 6-chip grid: Off / 1 / 5 / 15 / 30 / 60 min
- **Live countdown** to next scheduled auto-run
- **Animated Run Now button** — pulse effect while pipeline is active
- **Live pipeline panel** (SSE-driven):
  - ⏳ waiting → 🔄 running (+ sub-hint text) → ✅ done / ❌ failed
  - Orchestrator coordinator message bubble
- **Risk Score Ring** per shipment (0–100, animated)
- **Breach Probability Bar** — color-coded gradient
- **Expandable detail cards** — top triggers, recommended action, AI confidence %
- **Highest-risk fleet banner** alert
- Pull-to-refresh loads latest `predictions.json`
- TypeScript strict — **0 errors**

---


## Pydantic Schemas

```python
# sensor-analyst output
class SensorAnalysisOutput(BaseModel):
    shipments: List[SensorSignal]   # sensor_risk_score 0–100 per shipment
    analysis_summary: str

# pattern-matcher output
class PatternAnalysisOutput(BaseModel):
    shipments: List[PatternMatch]   # breach_probability_percent + time_to_breach
    highest_risk_shipment_id: Optional[str]

# risk-scorer output (written to predictions.json)
class PredictionOutput(BaseModel):
    shipments: List[ShipmentPrediction]  # final_risk_score, risk_level, recommended_action
    overall_fleet_risk: Literal["CRITICAL","HIGH","MEDIUM","LOW","SAFE"]
    scorer_summary: str
```

---

## Scoring Formula (risk-scorer)

```
final_risk_score = round(sensor_risk_score × 0.4 + pattern_risk_score × 0.6)

CRITICAL  → 80–100  → IMMEDIATE action
HIGH      → 60–79   → WITHIN_15_MIN
MEDIUM    → 40–59   → MONITOR
LOW/SAFE  → 0–39    → NO_ACTION
```
