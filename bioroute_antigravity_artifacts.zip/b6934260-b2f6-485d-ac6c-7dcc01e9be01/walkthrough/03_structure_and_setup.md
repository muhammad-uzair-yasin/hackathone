# Walkthrough — 03: Final File Structure & How to Run

## Project File Tree

```
hackathone/
├── PROJECT_SCOPE.md
├── README.md
├── pyproject.toml
├── .python-version
├── uv.lock
├── .gitignore
├── test_stream.py
├── test_stream2.py
├── test_stream3.py
│
├── langchain_agent/
│   ├── __init__.py
│   ├── llm.py                   ← claude_fast LLM client
│   ├── schemas.py               ← Pydantic schemas (4 agent outputs)
│   ├── tools.py                 ← update_crm_tool, notify_tool, write_summary_tool
│   ├── agent.py                 ← 4 subagents + orchestrator + middleware
│   └── api/
│       ├── __init__.py
│       └── server.py            ← FastAPI + SSE (6 endpoints)
│   └── data/
│       ├── active_shipments.json          ← Live CRM (mutated by agent)
│       ├── active_shipments_baseline.json ← Pristine copy for reset
│       ├── business_context.md
│       ├── news_scenarios.json
│       ├── notifications.json             ← Populated after agent run
│       ├── summary.md                     ← Agent run audit log
│       └── generate_news.py
│
├── webapp/
│   ├── index.html
│   ├── app.js
│   ├── map.js
│   └── styles.css
│
└── mobile/
    ├── App.tsx
    ├── app.json
    ├── package.json
    ├── tsconfig.json
    ├── .env.example
    ├── .env
    └── src/
        ├── screens/
        │   ├── IngestionDashboard.tsx
        │   ├── NewsInputScreen.tsx
        │   ├── AIDecisionEngine.tsx
        │   ├── OutcomeVisualization.tsx
        │   ├── FleetScreen.tsx
        │   ├── ShipmentDetailScreen.tsx
        │   └── AgentScreen.tsx
        ├── api/
        ├── hooks/
        ├── theme/
        ├── types/
        ├── components/
        └── utils/
```

---

## Quick Start

```bash
# Terminal 1 — Backend
uv run uvicorn langchain_agent.api.server:app --reload --port 8000

# Terminal 2 — Mobile
cd mobile
cp .env.example .env          # set EXPO_PUBLIC_API_URL to your local IP
npm install
npm start                     # press 'w' for browser, scan QR for phone

# Web Dashboard — no build needed
xdg-open webapp/index.html
# or: python3 -m http.server 3000 --directory webapp
```
