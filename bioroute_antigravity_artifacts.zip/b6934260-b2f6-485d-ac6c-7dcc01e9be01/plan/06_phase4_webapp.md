# Plan — 06: Phase 4 Planned Changes (Web Dashboard)

## Files to Create

### [NEW] `webapp/index.html`
Single-page dashboard — 3-panel layout: input / agent trace / outcome.

### [NEW] `webapp/app.js`
SSE client using `fetch` + `ReadableStream` (supports POST).
Renders step cards as each subagent completes.

### [NEW] `webapp/map.js`
SVG route map showing before/after shipment path with animation.

### [NEW] `webapp/styles.css`
Dark-mode design. Glassmorphism cards. Severity color coding.

## Acceptance Criteria
- Opens in browser with no build step
- Connects to backend at `http://localhost:8000`
- Step cards appear live as SSE events arrive
- Before/after panels update after agent completes
