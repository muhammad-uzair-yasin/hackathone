# Plan — 04: Phase 2 Planned Changes (Data Layer)

## Files to Create

### [NEW] `langchain_agent/data/active_shipments.json`
Mock CRM with Pakistani road network shipments. Each shipment has:
- 1 primary route (with GPS stops)
- **4 alternative routes** (A1–A4) with ETAs + notes

### [NEW] `langchain_agent/data/active_shipments_baseline.json`
Pristine copy — restored by `/api/reset`.

### [NEW] `langchain_agent/data/business_context.md`
Business rules injected into agent prompts:
- Max idle at 38°C: 45 min
- Spoilage cost: $50,000
- Rerouting trigger conditions

### [NEW] `langchain_agent/data/news_scenarios.json`
Pre-built alert scenarios for demo dropdown.

### [NEW] `langchain_agent/data/generate_news.py`
Script to generate additional test scenarios programmatically.

### [NEW] `langchain_agent/schemas.py`
Pydantic models for all 4 agent outputs:
- `HazardExtraction`
- `FleetScoutOutput`
- `ImpactAnalysis`
- `ActionPlan`

## Acceptance Criteria
- `active_shipments.json` has at least 2 shipments with real Pakistani routes
- Each shipment has exactly 4 alternatives in `alternative_routes[]`
- All 4 schemas import without error
- `ImpactAnalysis` has optional fields for the "no hazard" path
