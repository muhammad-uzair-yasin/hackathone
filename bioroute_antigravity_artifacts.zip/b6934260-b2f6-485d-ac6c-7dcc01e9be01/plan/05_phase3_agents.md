# Plan — 05: Phase 3 Planned Changes (LangChain Agents)

## Files to Create

### [NEW] `langchain_agent/llm.py`
`claude_fast` LLM client shared by orchestrator + all subagents.

### [NEW] `langchain_agent/tools.py`
Three orchestrator-level tools:
- `update_crm_tool` — mutates `active_shipments.json`
- `notify_tool` — appends to `notifications.json`
- `write_summary_tool` — writes `summary.md`

### [NEW] `langchain_agent/agent.py`
`create_deep_agent` definition with:
- 4 subagents with strict system prompts + `response_format`
- `CompositeBackend` (StateBackend + FilesystemBackend)
- `ModelRetryMiddleware` + `ToolRetryMiddleware`
- `build_agent()` + `get_agent()` singleton

## Subagent Pipeline

```
hazard-extractor  →  fleet-scout  →  impact-analyzer  →  action-planner
```

Each subagent receives the **full raw alert text** — never pre-parsed JSON from a previous agent.

## Orchestrator Workflow (7 steps, mandatory order)

1. `write_todos`
2. `task('hazard-extractor', raw_alert)`
3. If `hazard_detected` → `task('fleet-scout', raw_alert)`
4. If `hazard_detected` → `task('impact-analyzer', raw_alert + fleet_json)`
5. If `impact_detected` AND high risk → `task('action-planner', raw_alert + impact_json)`
6. If `urgency=IMMEDIATE/SOON` → `update_crm_tool()` then `notify_tool()`
7. `write_summary_tool()` — always last

## Acceptance Criteria
- End-to-end run completes without crashing
- `active_shipments.json` shows route change after run
- `notifications.json` has at least 1 record
- `summary.md` contains embedded pipeline JSON
