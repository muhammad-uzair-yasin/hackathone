# Plan — 07: Phase 5 Planned Changes (Mobile App)

## Files to Create

### [NEW] `mobile/` — Expo React Native project
Initialize with `npx create-expo-app`.

### [NEW] `mobile/App.tsx`
Stack navigator with 5 primary routes.

### [NEW] `mobile/src/screens/IngestionDashboard.tsx`
Home screen: active shipments + news alert input.

### [NEW] `mobile/src/screens/NewsInputScreen.tsx`
Scenario picker + manual text input + trigger button.

### [NEW] `mobile/src/screens/AIDecisionEngine.tsx`
Live SSE stream: step-by-step timeline stepper.

### [NEW] `mobile/src/screens/OutcomeVisualization.tsx`
Before/After toggle + notification log.

### [NEW] `mobile/src/screens/FleetScreen.tsx`
All active shipments overview.

### [NEW] `mobile/src/screens/ShipmentDetailScreen.tsx`
Individual shipment detail.

### [NEW] `mobile/src/screens/AgentScreen.tsx`
Last agent run audit view.

### [NEW] `mobile/src/api/`, `hooks/`, `theme/`, `types/`, `components/`, `utils/`
Supporting infrastructure for API calls, SSE hook, design tokens, TypeScript types.

### [NEW] `mobile/.env.example`
`EXPO_PUBLIC_API_URL=http://YOUR_IP:8000`

## Acceptance Criteria
- `npm start` launches Expo dev server
- App connects to backend via `EXPO_PUBLIC_API_URL`
- All 3 required hackathon screens work end-to-end
- SSE events render in real time on Screen 2
