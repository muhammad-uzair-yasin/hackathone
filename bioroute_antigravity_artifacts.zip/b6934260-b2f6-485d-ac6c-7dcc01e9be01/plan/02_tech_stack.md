# Plan — 02: Technology Stack

## Full Stack

| Layer | Technology | Version | Role |
|-------|-----------|---------|------|
| Agent Framework | LangChain Deep Agents (`deepagents`) | latest | Multi-agent orchestration |
| LLM | Anthropic Claude (`claude_fast`) | claude-3-haiku | LLM backend for all 4 subagents |
| Backend | FastAPI + Uvicorn | 0.11x | REST API + SSE streaming |
| Python pkg mgr | `uv` | latest | Fast dependency resolution |
| Mock CRM | JSON file (`active_shipments.json`) | — | Simulates CRM mutations |
| Web frontend | Vanilla HTML / JS / CSS | — | No build step needed |
| Mobile | React Native + Expo | SDK 52 | TypeScript mobile app |
| Node pkg mgr | npm | — | Mobile dependencies |

## Why `uv` over `pip`/`poetry`?

`uv` resolves and installs Python dependencies significantly faster than pip. For a 24-hour hackathon sprint, reducing environment setup time matters. `uv run` also lets us launch uvicorn without activating a venv manually.

## Why React Native over Flutter?

- Shared TypeScript types directly match Pydantic backend schemas
- Expo Go app allows instant device testing without native build
- Faster iteration for solo developer on a time-boxed sprint
- Team already familiar with JS ecosystem

## Why SSE over WebSockets?

- Unidirectional (server → client) — matches agent stream output pattern exactly
- No handshake overhead
- Works with React Native's `fetch` + `ReadableStream`
- Simpler to debug (plain text `data:` lines)
