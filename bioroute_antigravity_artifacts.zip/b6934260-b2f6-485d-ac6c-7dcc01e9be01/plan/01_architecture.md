# Plan — 01: System Architecture

## End-to-End Flow

```
[User / Operator]
      │ paste news alert text
      ▼
[FastAPI Server]  POST /api/analyze  →  SSE stream back
      │
      ▼
[LangChain Deep Agent Orchestrator]
      │
      ├─ task('hazard-extractor')   →  HazardExtraction JSON
      │         ↓
      ├─ task('fleet-scout')        →  FleetScoutOutput JSON
      │         ↓
      ├─ task('impact-analyzer')    →  ImpactAnalysis JSON
      │         ↓
      └─ task('action-planner')     →  ActionPlan JSON
                ↓
      [Orchestrator Tools]
      ├─ update_crm_tool()          →  writes active_shipments.json  ← BEFORE/AFTER
      ├─ notify_tool()              →  writes notifications.json
      └─ write_summary_tool()       →  writes summary.md
                ↓
      [Frontend consumers]
      ├─ Web Dashboard  (SSE stream → live trace + map)
      └─ Mobile App     (SSE stream → step timeline + outcome)
```

## Key Architectural Decisions

| Decision | Choice | Why |
|----------|--------|-----|
| Agent framework | LangChain Deep Agents | Hackathon requirement |
| LLM | Anthropic Claude | Best structured output reliability |
| API style | SSE streaming | Enables live agent trace in UI |
| CRM | Local JSON file | Simple, demonstrable mutation |
| Mobile | React Native (Expo) | Faster than Flutter for solo dev |
| Web | Vanilla HTML/JS | No build step, instant demo |
