# Plan — 03: Phase 1 Planned Changes (Backend)

## Files to Create

### [NEW] `pyproject.toml`
Python project manifest with `uv`-compatible dependency list.

### [NEW] `.python-version`
Pin to Python 3.13.

### [NEW] `langchain_agent/__init__.py`
Package marker.

### [NEW] `langchain_agent/api/__init__.py`
Package marker for API module.

### [NEW] `langchain_agent/api/server.py`
FastAPI application with SSE streaming.

**Endpoints:**

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/analyze` | Main endpoint — SSE stream for web |
| GET | `/api/stream` | SSE stream via query param for mobile |
| GET | `/api/scenarios` | Returns list of news test scenarios |
| GET | `/api/db` | Returns live CRM + last session summary |
| POST | `/api/reset` | Resets demo data to baseline |
| GET | `/health` | Health check |

**CORS:** `allow_origins=["*"]` — permits both web (file://) and mobile (local IP).

## Acceptance Criteria
- `uv run uvicorn langchain_agent.api.server:app --port 8000` starts without error
- `GET /health` returns `{"status": "ok"}`
- `GET /api/db` returns JSON with `active_shipments` array
