# Plan — 08: Verification Plan

## Demo Scenario (Primary)

```
Input: "Multi-vehicle collision blocks N-5 National Highway near Hyderabad.
        Temperatures at 42–44°C. Jamshoro route completely closed."

Expected pipeline output:
  Step 1 → hazard_detected: true, severity: CRITICAL, temp: 42°C
  Step 2 → SHP-882 on N-5 (insulin, 40min ETA)
  Step 3 → impact_detected: true, time_to_failure: 20min, $50K risk
  Step 4 → selected: M-9 Thatta Bypass (A1)
  CRM   → SHP-882 status: "Emergency Reroute", route: M-9 Thatta Bypass
  Notif → NOTIF-SHP-882-HHMMSS sent to Liaquat University Hospital
```

## Test Commands

```bash
# 1. Start backend
uv run uvicorn langchain_agent.api.server:app --reload --port 8000

# 2. Health check
curl http://localhost:8000/health

# 3. Run demo scenario
curl -X POST http://localhost:8000/api/analyze \
  -H "Content-Type: application/json" \
  -d '{"input": "Multi-vehicle collision blocks N-5 near Hyderabad. 42C heat."}'

# 4. Verify CRM mutation
curl http://localhost:8000/api/db | python3 -m json.tool

# 5. Reset for next run
curl -X POST http://localhost:8000/api/reset
```

## Manual Checks

- [ ] `active_shipments.json` shows `"Emergency Reroute"` after run
- [ ] `notifications.json` has a record with `"SENT (simulated)"`
- [ ] `summary.md` contains embedded `<!--BIOROUTE_PIPELINE` JSON block
- [ ] Web dashboard shows before=green, after=red route cards
- [ ] Mobile Screen 2 (AIDecisionEngine) shows 4 step cards in sequence
- [ ] Mobile Screen 3 (OutcomeVisualization) toggle shows route change
